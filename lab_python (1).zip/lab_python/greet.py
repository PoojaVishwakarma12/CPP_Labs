# Ask the user for their name
name = input("Enter your name: ")

# Print greeting message
print("Hello", name)