# Ask user for inputs
basic_rate = float(input("Enter basic pay rate per hour: "))
regular_hours = float(input("Enter regular hours per week: "))
overtime_hours = float(input("Enter overtime hours per week: "))

# Calculate basic pay
basic_pay = basic_rate * regular_hours

# Calculate overtime pay
overtime_rate = basic_rate * 1.5
overtime_pay = overtime_rate * overtime_hours

# Calculate total pay
total_pay = basic_pay + overtime_pay

# Display results
print("Basic Pay:", basic_pay)
print("Overtime Pay:", overtime_pay)
print("Total Pay:", total_pay)