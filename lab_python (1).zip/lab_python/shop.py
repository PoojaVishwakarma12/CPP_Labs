# Prices
cap_price = 5
shirt_price = 10
hoodie_price = 20

# Ask user for quantity
caps = int(input("Enter number of caps: "))
shirts = int(input("Enter number of shirts: "))
hoodies = int(input("Enter number of hoodies: "))

# Calculate cost
total = (caps * cap_price) + (shirts * shirt_price) + (hoodies * hoodie_price)

# Display total
print("Total cost is:", total)