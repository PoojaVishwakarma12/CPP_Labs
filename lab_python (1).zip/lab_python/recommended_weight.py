# Step 1: Ask user for age
age = int(input("Enter your age: "))

# Step 2: Ask user for height
height = float(input("Enter your height in cm: "))

# Step 3: Calculate recommended weight
rw = (height - 100 + age % 10) * 0.90

# Step 4: Display the result
print("Recommended Weight:", rw)