from flask import Flask, request, render_template

app = Flask(__name__)

# Step 4: Create route for login
@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ""  # Initialize message variable
    if request.method == 'POST':
        # Step 5: Capture form input
        username = request.form.get('username')
        if username:
            message = f"Hello, {username}! Login successful."
        else:
            message = "Please enter a username."
    # Step 6: Render HTML template
    return render_template('login.html', message=message)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080, debug=True)