from flask import Flask, render_template

app = Flask(__name__)

# Home page route
@app.route('/')
def home():
    # List of users
    users = ["Alice", "Bob", "Charlie"]
    return render_template("home.html", users=users)

# Dynamic profile route
@app.route('/user/<username>')
def profile(username):
    return render_template("profile.html", username=username)

# Run the app
# if __name__ == "__main__":
#     app.run(debug=True)
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080, debug=True)