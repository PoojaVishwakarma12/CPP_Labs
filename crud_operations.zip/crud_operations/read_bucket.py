import boto3

s3 = boto3.client('s3')

response = s3.list_buckets()

for bucket in response['Buckets']:
    print(bucket['Name'])
    

MyBucket = "nci-cpp-class-2027"

# List all the files in the bucket

bucketFiles = s3.list_objects_v2(Bucket=MyBucket)

#print(bucketFiles)

# Reading all the Object names present in Bucket
if 'Contents' in bucketFiles:
    for item in bucketFiles['Contents']:
        print(item["Key"])
        
# Reading the content of an Object
myfile= "hello_on_s3.txt"
print(f"\n Reading {myfile}")

readObj = s3.get_object(Bucket=MyBucket, Key=myfile)
print(readObj)

readText = readObj['Body'].read().decode('utf-8')
print(readText)