# List All the existing Buckets on S3 in my account

import boto3

# 1. Initialising the S3 Client
s3 = boto3.client("s3")

"""
# 2. Taking the response from list_buckets
response = s3.list_buckets()

#print(response)

for bucket in response["Buckets"]:
    print(f" - {bucket['Name']}")
    print(f" - {bucket['CreationDate']}")
"""

#3. Create a new bucket
# Bucket names have to be universally/globally unique
# Adding some specific or some random text in the bucket name

new_bucket_name = "nci-cpp-class-2027"

s3.create_bucket(Bucket=new_bucket_name)

s3 = boto3.client("s3")
response = s3.list_buckets()

#print(response)

for bucket in response["Buckets"]:
    print(f" - {bucket['Name']}")
    print(f" - {bucket['CreationDate']}")


#4. Creating a Dummy File locally then upload it to newly created bucket

with open("test.txt", "w") as f:
    f.write("Hello this test file is created using Boto3!")
    
#4.1 Upload the above file to s3 bucket

s3.upload_file("test.txt",new_bucket_name,"hello_on_s3.txt")
print("File Uploaded")