# main.py
from fastapi import FastAPI

app = FastAPI()

# In-memory "database"
tasks = [
    {"id": 1, "title": "Learn FastAPI", "description": "Build APIs on AWS", "done": False},
    {"id": 2, "title": "Prepare lecture", "description": "Week 3 RESTful APIs", "done": False},
]

@app.get("/")
async def root():
    return {"message": "Hello, FastAPI!"}

@app.get("/tasks")
async def list_tasks():
    return tasks
