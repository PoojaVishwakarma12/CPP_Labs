# pip install fastapi uvicorn
# uvicorn main:app --reload --host 0.0.0.0 --port 8000

# main.py
from fastapi import FastAPI, HTTPException, status
from fastapi import FastAPI
from typing import List
from pydantic import BaseModel


app = FastAPI()

# In-memory "database"
tasks = []
next_id = 1


@app.get("/")
def root():
    return {"message": "Hello, FastAPI!"}


# List all tasks
@app.get("/tasks")
def list_tasks():
    return tasks


# Get a single task
@app.get("/tasks/{task_id}")
def get_task(task_id: int):
    for task in tasks:
        if task["id"] == task_id:
            return task
    raise HTTPException(status_code=404, detail="Task not found")


# Create a new task
@app.post("/tasks")
def create_task(task: dict):
    """
    Expected body:
    {
      "title": "Learn FastAPI",
      "description": "My first task"
    }
    """
    global next_id

    new_task = {
        "id": next_id,
        "title": task["title"],
        "description": task["description"],
        "done": False,
    }

    tasks.append(new_task)
    next_id += 1
    return new_task


# Update a task
@app.put("/tasks/{task_id}")
def update_task(task_id: int, task: dict):
    """
    Example body (all fields required):
    {
      "title": "Updated title",
      "description": "Updated description",
      "done": true
    }
    """
    for existing in tasks:
        if existing["id"] == task_id:
            existing["title"] = task["title"]
            existing["description"] = task["description"]
            existing["done"] = task["done"]
            return existing

    raise HTTPException(status_code=404, detail="Task not found")


# Delete a task
@app.delete("/tasks/{task_id}")
def delete_task(task_id: int):
    for task in tasks:
        if task["id"] == task_id:
            tasks.remove(task)
            return {"message": "Task deleted"}

    raise HTTPException(status_code=404, detail="Task not found")

